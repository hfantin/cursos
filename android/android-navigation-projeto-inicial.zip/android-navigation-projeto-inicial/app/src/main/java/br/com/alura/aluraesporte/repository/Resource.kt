package br.com.alura.aluraesporte.repository

class Resource<T>(val dado: T)
