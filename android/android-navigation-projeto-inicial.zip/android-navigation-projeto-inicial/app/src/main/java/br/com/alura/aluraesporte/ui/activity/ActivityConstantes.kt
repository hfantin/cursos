package br.com.alura.aluraesporte.ui.activity

const val CHAVE_PRODUTO_ID = "produtoId"