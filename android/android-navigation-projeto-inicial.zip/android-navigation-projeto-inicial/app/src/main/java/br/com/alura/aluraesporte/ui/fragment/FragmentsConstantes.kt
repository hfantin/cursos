package br.com.alura.aluraesporte.ui.fragment

const val ID_PRODUTO_INVALIDO = "id do produto inválido"